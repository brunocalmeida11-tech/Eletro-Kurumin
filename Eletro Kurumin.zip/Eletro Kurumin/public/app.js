const $ = (id) => document.getElementById(id);
const money = (v) => Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const dateTime = (v) => new Date(v).toLocaleString('pt-BR');
let usuario = null, componentes = [], categorias = [], isRegister = false;

async function api(url, options = {}) {
  const response = await fetch('/api' + url, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = response.status === 204 ? null : await response.json();
  if (!response.ok) throw new Error(data?.mensagem || 'Ocorreu um erro na solicitação.');
  return data;
}
function toast(msg) {
  $('toast').textContent = msg; $('toast').classList.add('show');
  setTimeout(() => $('toast').classList.remove('show'), 2600);
}
function showAuth(register = false) {
  isRegister = register;
  $('nome-wrap').classList.toggle('hidden', !register);
  $('auth-title').textContent = register ? 'Crie sua conta' : 'Acesse sua conta';
  $('auth-subtitle').textContent = register ? 'Preencha os dados para começar.' : 'Entre com seus dados para continuar.';
  $('auth-submit').innerHTML = register ? 'Criar conta <span>→</span>' : 'Entrar no sistema <span>→</span>';
  $('auth-switch').innerHTML = register
    ? 'Já possui acesso? <button type="button" id="toggle-auth">Fazer login</button>'
    : 'Ainda não tem acesso? <button type="button" id="toggle-auth">Criar uma conta</button>';
  $('toggle-auth').addEventListener('click', () => showAuth(!isRegister));
  $('auth-message').textContent = '';
}
$('toggle-auth').addEventListener('click', () => showAuth(true));
$('auth-form').addEventListener('submit', async (e) => {
  e.preventDefault(); $('auth-message').textContent = '';
  try {
    const body = { email: $('auth-email').value.trim(), senha: $('auth-senha').value };
    if (isRegister) body.nome = $('auth-nome').value.trim();
    const data = await api('/auth/' + (isRegister ? 'cadastro' : 'login'), { method: 'POST', body: JSON.stringify(body) });
    usuario = data.usuario; openApp();
  } catch (err) { $('auth-message').textContent = err.message; }
});
async function checkSession() {
  try { const data = await api('/auth/sessao'); if (data.usuario) { usuario = data.usuario; openApp(); } }
  catch { /* sessão ainda não iniciada */ }
}
function openApp() {
  $('auth-view').classList.add('hidden'); $('app-view').classList.remove('hidden');
  $('user-name').textContent = usuario.nome; $('welcome-name').textContent = usuario.nome.split(' ')[0];
  $('user-avatar').textContent = usuario.nome.charAt(0).toUpperCase();
  $('today-date').textContent = new Date().toLocaleDateString('pt-BR', { dateStyle: 'long' });
  carregarTudo();
}
$('logout-btn').addEventListener('click', async () => {
  await api('/auth/logout', { method: 'POST' }); usuario = null;
  $('app-view').classList.add('hidden'); $('auth-view').classList.remove('hidden');
  $('auth-form').reset(); showAuth(false);
});
document.querySelectorAll('.nav-link').forEach(btn => btn.addEventListener('click', () => navegar(btn.dataset.page)));
document.querySelectorAll('[data-goto]').forEach(btn => btn.addEventListener('click', () => navegar(btn.dataset.goto)));
function navegar(page) {
  document.querySelectorAll('.page').forEach(el => el.classList.add('hidden'));
  $('page-' + page).classList.remove('hidden');
  document.querySelectorAll('.nav-link').forEach(el => el.classList.toggle('active', el.dataset.page === page));
  $('page-title').textContent = ({ dashboard: 'Visão geral', componentes: 'Componentes', movimentacoes: 'Movimentações', relatorios: 'Relatórios' })[page];
  if (page === 'relatorios') carregarRelatorio();
  if (page === 'movimentacoes') carregarMovimentacoes();
}
async function carregarTudo() {
  try {
    [categorias, componentes] = await Promise.all([api('/categorias'), api('/componentes')]);
    preencherCategorias(); renderComponentes(); atualizarDashboard(); preencherSelectMovimento();
    carregarMovimentacoes();
  } catch (err) { toast(err.message); }
}
function preencherCategorias() {
  const options = categorias.map(c => `<option value="${c.id_categoria}">${escapeHtml(c.nome)}</option>`).join('');
  $('component-category').innerHTML = options;
  $('filter-category').innerHTML = '<option value="">Todas as categorias</option>' + options;
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
}
function valor(c) { return Number(c.preco) * Number(c.quantidade_estoque); }
function linhasComponentes(lista, dashboard = false) {
  if (!lista.length) return `<tr><td colspan="${dashboard ? 5 : 6}">Nenhum componente cadastrado.</td></tr>`;
  return lista.map(c => `<tr>
    <td><span class="component-name">${escapeHtml(c.nome)}</span></td>
    <td><span class="pill">${escapeHtml(c.categoria)}</span></td>
    <td>${money(c.preco)}</td><td class="${c.quantidade_estoque <= 5 ? 'stock-low' : ''}">${c.quantidade_estoque} un.</td>
    <td><b>${money(valor(c))}</b></td>
    ${dashboard ? '' : `<td><div class="actions"><button class="action-btn" onclick="editarComponente(${c.id_componente})">Editar</button><button class="action-btn delete" onclick="excluirComponente(${c.id_componente})">Excluir</button></div></td>`}
  </tr>`).join('');
}
function renderComponentes() {
  const busca = $('search-component').value.toLowerCase();
  const cat = $('filter-category').value;
  const filtrados = componentes.filter(c => c.nome.toLowerCase().includes(busca) && (!cat || String(c.id_categoria) === cat));
  $('components-table').innerHTML = linhasComponentes(filtrados);
  $('dashboard-table').innerHTML = linhasComponentes(componentes.slice(0, 6), true);
}
$('search-component').addEventListener('input', renderComponentes);
$('filter-category').addEventListener('change', renderComponentes);
function atualizarDashboard() {
  $('stat-tipos').textContent = componentes.length;
  $('stat-unidades').textContent = componentes.reduce((s,c) => s + Number(c.quantidade_estoque), 0);
  $('stat-valor').textContent = money(componentes.reduce((s,c) => s + valor(c), 0));
  $('stat-baixo').textContent = componentes.filter(c => Number(c.quantidade_estoque) <= 5).length;
  renderComponentes();
}
$('new-component').addEventListener('click', () => {
  $('component-form').reset(); $('component-id').value = '';
  $('component-modal-title').textContent = 'Novo componente'; $('component-message').textContent = '';
  $('component-dialog').showModal();
});
window.editarComponente = (id) => {
  const c = componentes.find(x => x.id_componente === id); if (!c) return;
  $('component-id').value = c.id_componente; $('component-name').value = c.nome;
  $('component-category').value = c.id_categoria; $('component-description').value = c.descricao || '';
  $('component-price').value = c.preco; $('component-quantity').value = c.quantidade_estoque;
  $('component-modal-title').textContent = 'Editar componente'; $('component-message').textContent = '';
  $('component-dialog').showModal();
};
$('component-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = $('component-id').value;
  const body = { nome: $('component-name').value, id_categoria: $('component-category').value,
    descricao: $('component-description').value, preco: $('component-price').value,
    quantidade_estoque: $('component-quantity').value };
  try {
    await api('/componentes' + (id ? '/' + id : ''), { method: id ? 'PUT' : 'POST', body: JSON.stringify(body) });
    $('component-dialog').close(); toast(id ? 'Componente atualizado!' : 'Componente cadastrado!');
    await carregarTudo();
  } catch (err) { $('component-message').textContent = err.message; }
});
window.excluirComponente = async (id) => {
  if (!confirm('Tem certeza que deseja excluir este componente? O histórico de movimentações dele também será removido.')) return;
  try { await api('/componentes/' + id, { method: 'DELETE' }); toast('Componente excluído.'); await carregarTudo(); }
  catch (err) { toast(err.message); }
};
function preencherSelectMovimento() {
  $('movement-component').innerHTML = componentes.map(c =>
    `<option value="${c.id_componente}">${escapeHtml(c.nome)} — ${c.quantidade_estoque} un.</option>`).join('');
}
$('new-movement').addEventListener('click', () => {
  if (!componentes.length) return toast('Cadastre um componente primeiro.');
  $('movement-form').reset(); $('movement-message').textContent = '';
  preencherSelectMovimento(); $('movement-dialog').showModal();
});
$('movement-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = { id_componente: $('movement-component').value, tipo: $('movement-type').value,
    quantidade: $('movement-quantity').value, justificativa: $('movement-reason').value };
  try {
    await api('/movimentacoes', { method: 'POST', body: JSON.stringify(body) });
    $('movement-dialog').close(); toast('Movimentação registrada!');
    await carregarTudo();
  } catch (err) { $('movement-message').textContent = err.message; }
});
async function carregarMovimentacoes() {
  try {
    const rows = await api('/movimentacoes');
    $('movements-table').innerHTML = rows.length ? rows.map(m => `<tr>
      <td>${dateTime(m.data_movimentacao)}</td><td class="component-name">${escapeHtml(m.componente)}</td>
      <td><span class="pill">${m.tipo === 'entrada' ? 'Entrada' : 'Saída'}</span></td>
      <td>${m.quantidade} un.</td><td>${escapeHtml(m.usuario)}</td><td>${escapeHtml(m.justificativa)}</td>
    </tr>`).join('') : '<tr><td colspan="6">Nenhuma movimentação registrada.</td></tr>';
  } catch (err) { toast(err.message); }
}
async function carregarRelatorio() {
  try {
    const data = await api('/relatorios');
    $('report-value').textContent = money(data.resumo.valor_estoque);
    $('report-table').innerHTML = data.itens.length ? data.itens.map(c => `<tr>
      <td class="component-name">${escapeHtml(c.nome)}</td><td><span class="pill">${escapeHtml(c.categoria)}</span></td>
      <td>${money(c.preco)}</td><td>${c.quantidade_estoque} un.</td><td><b>${money(c.valor_total)}</b></td>
    </tr>`).join('') : '<tr><td colspan="5">Nenhum componente cadastrado.</td></tr>';
  } catch (err) { toast(err.message); }
}
$('print-report').addEventListener('click', () => window.print());
document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', () => $(btn.dataset.close).close()));
checkSession();
