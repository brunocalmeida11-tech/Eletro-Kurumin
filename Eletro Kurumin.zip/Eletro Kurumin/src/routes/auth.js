const router = require('express').Router();
const bcrypt = require('bcryptjs');
const pool = require('../database');

router.post('/cadastro', async (req, res) => {
  try {
    const { nome, email, senha } = req.body;
    if (!nome || !email || !senha || senha.length < 6)
      return res.status(400).json({ mensagem: 'Informe nome, e-mail e senha com pelo menos 6 caracteres.' });
    const [existe] = await pool.query('SELECT id_usuario FROM usuario WHERE email = ?', [email]);
    if (existe.length) return res.status(409).json({ mensagem: 'Este e-mail já está cadastrado.' });
    const hash = await bcrypt.hash(senha, 10);
    const [result] = await pool.query(
      'INSERT INTO usuario (nome, email, senha) VALUES (?, ?, ?)', [nome, email, hash]
    );
    req.session.usuario = { id: result.insertId, nome, email };
    res.status(201).json({ mensagem: 'Conta criada com sucesso.', usuario: req.session.usuario });
  } catch (erro) {
    console.error(erro);
    res.status(500).json({ mensagem: 'Não foi possível criar a conta.' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, senha } = req.body;
    const [rows] = await pool.query('SELECT * FROM usuario WHERE email = ?', [email]);
    if (!rows.length || !(await bcrypt.compare(senha || '', rows[0].senha)))
      return res.status(401).json({ mensagem: 'E-mail ou senha incorretos.' });
    req.session.usuario = { id: rows[0].id_usuario, nome: rows[0].nome, email: rows[0].email };
    res.json({ mensagem: 'Login realizado.', usuario: req.session.usuario });
  } catch (erro) {
    console.error(erro);
    res.status(500).json({ mensagem: 'Erro ao realizar login.' });
  }
});

router.get('/sessao', (req, res) => res.json({ usuario: req.session.usuario || null }));
router.post('/logout', (req, res) => req.session.destroy(() => res.json({ mensagem: 'Sessão encerrada.' })));
module.exports = router;