const router = require('express').Router();
const pool = require('../database');
const auth = require('../middleware/auth');
router.use(auth);

router.get('/', async (_req, res) => {
  try {
    const [itens] = await pool.query(
      `SELECT c.id_componente, c.nome, c.descricao, c.preco, c.quantidade_estoque,
              cat.nome AS categoria,
              (c.preco * c.quantidade_estoque) AS valor_total
       FROM componente c JOIN categoria cat ON cat.id_categoria=c.id_categoria
       ORDER BY cat.nome, c.nome`
    );
    const [resumo] = await pool.query(
      `SELECT COUNT(*) AS total_tipos,
              COALESCE(SUM(quantidade_estoque),0) AS total_unidades,
              COALESCE(SUM(preco * quantidade_estoque),0) AS valor_estoque
       FROM componente`
    );
    res.json({ itens, resumo: resumo[0] });
  } catch { res.status(500).json({ mensagem: 'Erro ao gerar relatório.' }); }
});
module.exports = router;