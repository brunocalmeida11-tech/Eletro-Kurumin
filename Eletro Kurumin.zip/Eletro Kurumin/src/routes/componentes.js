const router = require('express').Router();
const pool = require('../database');
const auth = require('../middleware/auth');
router.use(auth);

const campos = `SELECT c.*, cat.nome AS categoria, u.nome AS responsavel
  FROM componente c JOIN categoria cat ON cat.id_categoria = c.id_categoria
  JOIN usuario u ON u.id_usuario = c.id_usuario`;

router.get('/', async (_req, res) => {
  try { const [rows] = await pool.query(`${campos} ORDER BY c.nome`); res.json(rows); }
  catch { res.status(500).json({ mensagem: 'Erro ao listar componentes.' }); }
});
router.post('/', async (req, res) => {
  try {
    const { id_categoria, nome, descricao, preco, quantidade_estoque } = req.body;
    if (!id_categoria || !nome?.trim() || !Number.isFinite(Number(preco)) ||
        Number(preco) < 0 || !Number.isInteger(Number(quantidade_estoque)) || Number(quantidade_estoque) < 0)
      return res.status(400).json({ mensagem: 'Confira os campos obrigatórios e os valores.' });
    const [r] = await pool.query(
      `INSERT INTO componente (id_categoria, id_usuario, nome, descricao, preco, quantidade_estoque)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id_categoria, req.session.usuario.id, nome.trim(), descricao || '', preco, quantidade_estoque]
    );
    if (Number(quantidade_estoque) > 0) {
      await pool.query(
        `INSERT INTO movimentacao (id_componente, id_usuario, tipo, quantidade, justificativa)
         VALUES (?, ?, 'entrada', ?, 'Estoque inicial')`,
        [r.insertId, req.session.usuario.id, quantidade_estoque]
      );
    }
    res.status(201).json({ mensagem: 'Componente cadastrado.', id: r.insertId });
  } catch (erro) { console.error(erro); res.status(400).json({ mensagem: 'Não foi possível cadastrar. Verifique a categoria.' }); }
});
router.put('/:id', async (req, res) => {
  try {
    const { id_categoria, nome, descricao, preco, quantidade_estoque } = req.body;
    if (!id_categoria || !nome?.trim() || Number(preco) < 0 ||
        !Number.isInteger(Number(quantidade_estoque)) || Number(quantidade_estoque) < 0)
      return res.status(400).json({ mensagem: 'Confira os campos informados.' });
    const [atual] = await pool.query('SELECT quantidade_estoque FROM componente WHERE id_componente = ?', [req.params.id]);
    if (!atual.length) return res.status(404).json({ mensagem: 'Componente não encontrado.' });
    const diferenca = Number(quantidade_estoque) - atual[0].quantidade_estoque;
    await pool.query(
      `UPDATE componente SET id_categoria=?, nome=?, descricao=?, preco=?, quantidade_estoque=?
       WHERE id_componente=?`,
      [id_categoria, nome.trim(), descricao || '', preco, quantidade_estoque, req.params.id]
    );
    if (diferenca !== 0) {
      await pool.query(
        `INSERT INTO movimentacao (id_componente, id_usuario, tipo, quantidade, justificativa)
         VALUES (?, ?, ?, ?, 'Ajuste pelo formulário de edição')`,
        [req.params.id, req.session.usuario.id, diferenca > 0 ? 'entrada' : 'saida', Math.abs(diferenca)]
      );
    }
    res.json({ mensagem: 'Componente atualizado.' });
  } catch (erro) { console.error(erro); res.status(400).json({ mensagem: 'Erro ao atualizar componente.' }); }
});
router.delete('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id_componente FROM componente WHERE id_componente=?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ mensagem: 'Componente não encontrado.' });
    await pool.query('DELETE FROM movimentacao WHERE id_componente=?', [req.params.id]);
    await pool.query('DELETE FROM componente WHERE id_componente=?', [req.params.id]);
    res.json({ mensagem: 'Componente removido.' });
  } catch (erro) { console.error(erro); res.status(500).json({ mensagem: 'Erro ao excluir componente.' }); }
});
module.exports = router;