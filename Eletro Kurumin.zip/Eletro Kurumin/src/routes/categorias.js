const router = require('express').Router();
const pool = require('../database');
const auth = require('../middleware/auth');
router.use(auth);

router.get('/', async (_req, res) => {
  try { const [rows] = await pool.query('SELECT * FROM categoria ORDER BY nome'); res.json(rows); }
  catch { res.status(500).json({ mensagem: 'Erro ao listar categorias.' }); }
});
router.post('/', async (req, res) => {
  try {
    const { nome } = req.body;
    if (!nome?.trim()) return res.status(400).json({ mensagem: 'Informe o nome da categoria.' });
    const [r] = await pool.query('INSERT INTO categoria (nome) VALUES (?)', [nome.trim()]);
    res.status(201).json({ id_categoria: r.insertId, nome: nome.trim() });
  } catch { res.status(400).json({ mensagem: 'Categoria já cadastrada ou dados inválidos.' }); }
});
module.exports = router;