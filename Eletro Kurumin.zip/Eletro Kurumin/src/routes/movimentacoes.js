const router = require('express').Router();
const pool = require('../database');
const auth = require('../middleware/auth');
router.use(auth);

router.get('/', async (_req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT m.*, c.nome AS componente, u.nome AS usuario
       FROM movimentacao m JOIN componente c ON c.id_componente=m.id_componente
       JOIN usuario u ON u.id_usuario=m.id_usuario
       ORDER BY m.data_movimentacao DESC LIMIT 100`
    );
    res.json(rows);
  } catch { res.status(500).json({ mensagem: 'Erro ao carregar movimentações.' }); }
});

router.post('/', async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const { id_componente, tipo, quantidade, justificativa } = req.body;
    const qtd = Number(quantidade);
    if (!id_componente || !['entrada', 'saida'].includes(tipo) || !Number.isInteger(qtd) || qtd <= 0)
      return res.status(400).json({ mensagem: 'Informe componente, tipo e quantidade válida.' });
    await connection.beginTransaction();
    const [rows] = await connection.query(
      'SELECT quantidade_estoque FROM componente WHERE id_componente=? FOR UPDATE', [id_componente]
    );
    if (!rows.length) { await connection.rollback(); return res.status(404).json({ mensagem: 'Componente não encontrado.' }); }
    const atual = rows[0].quantidade_estoque;
    const novo = tipo === 'entrada' ? atual + qtd : atual - qtd;
    if (novo < 0) { await connection.rollback(); return res.status(400).json({ mensagem: 'Estoque insuficiente para essa saída.' }); }
    await connection.query('UPDATE componente SET quantidade_estoque=? WHERE id_componente=?', [novo, id_componente]);
    await connection.query(
      `INSERT INTO movimentacao (id_componente,id_usuario,tipo,quantidade,justificativa)
       VALUES (?,?,?,?,?)`,
      [id_componente, req.session.usuario.id, tipo, qtd, justificativa || 'Sem justificativa']
    );
    await connection.commit();
    res.status(201).json({ mensagem: 'Movimentação registrada.' });
  } catch (erro) {
    await connection.rollback();
    console.error(erro);
    res.status(500).json({ mensagem: 'Erro ao registrar movimentação.' });
  } finally { connection.release(); }
});
module.exports = router;