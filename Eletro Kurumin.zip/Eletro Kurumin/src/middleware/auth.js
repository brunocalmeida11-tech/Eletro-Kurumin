module.exports = function (req, res, next) {
  if (!req.session.usuario) {
    return res.status(401).json({ mensagem: 'Faça login para continuar.' });
  }
  next();
};