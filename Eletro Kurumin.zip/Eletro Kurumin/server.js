require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const pool = require('./src/database');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'chave-local-eletro-kurumin',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 8 }
}));

app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/categorias', require('./src/routes/categorias'));
app.use('/api/componentes', require('./src/routes/componentes'));
app.use('/api/movimentacoes', require('./src/routes/movimentacoes'));
app.use('/api/relatorios', require('./src/routes/relatorios'));

app.get('/api/status', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ online: true }); }
  catch { res.status(500).json({ online: false, mensagem: 'Banco de dados indisponível.' }); }
});
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Eletro Kurumin rodando em http://localhost:${PORT}`));