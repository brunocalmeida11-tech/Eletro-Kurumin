CREATE DATABASE IF NOT EXISTS eletro_kurumin
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE eletro_kurumin;

CREATE TABLE IF NOT EXISTS usuario (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categoria (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS componente (
  id_componente INT AUTO_INCREMENT PRIMARY KEY,
  id_categoria INT NOT NULL,
  id_usuario INT NOT NULL,
  nome VARCHAR(120) NOT NULL,
  descricao TEXT,
  preco DECIMAL(10,2) NOT NULL DEFAULT 0,
  quantidade_estoque INT NOT NULL DEFAULT 0,
  CONSTRAINT fk_componente_categoria FOREIGN KEY (id_categoria)
    REFERENCES categoria(id_categoria),
  CONSTRAINT fk_componente_usuario FOREIGN KEY (id_usuario)
    REFERENCES usuario(id_usuario),
  CONSTRAINT chk_preco CHECK (preco >= 0),
  CONSTRAINT chk_quantidade CHECK (quantidade_estoque >= 0)
);

CREATE TABLE IF NOT EXISTS movimentacao (
  id_movimentacao INT AUTO_INCREMENT PRIMARY KEY,
  id_componente INT NOT NULL,
  id_usuario INT NOT NULL,
  data_movimentacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  tipo ENUM('entrada', 'saida') NOT NULL,
  quantidade INT NOT NULL,
  justificativa VARCHAR(255),
  CONSTRAINT fk_mov_componente FOREIGN KEY (id_componente)
    REFERENCES componente(id_componente),
  CONSTRAINT fk_mov_usuario FOREIGN KEY (id_usuario)
    REFERENCES usuario(id_usuario),
  CONSTRAINT chk_mov_quantidade CHECK (quantidade > 0)
);

INSERT IGNORE INTO categoria (nome) VALUES
('Processadores'), ('Memórias'), ('Armazenamento'),
('Placas de vídeo'), ('Fontes'), ('Periféricos'), ('Outros');